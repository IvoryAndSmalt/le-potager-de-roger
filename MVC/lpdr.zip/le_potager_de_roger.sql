-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le :  sam. 09 fév. 2019 à 15:20
-- Version du serveur :  10.1.37-MariaDB
-- Version de PHP :  7.3.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `le_potager_de_roger`
--

-- --------------------------------------------------------

--
-- Structure de la table `categories`
--

CREATE TABLE `categories` (
  `id_categorie` int(11) NOT NULL,
  `type` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `categories`
--

INSERT INTO `categories` (`id_categorie`, `type`) VALUES
(1, 'Fruits'),
(2, 'Légumes');

-- --------------------------------------------------------

--
-- Structure de la table `offres`
--

CREATE TABLE `offres` (
  `id_offre` int(11) NOT NULL,
  `url_photo` varchar(5) NOT NULL,
  `commentaire` varchar(255) NOT NULL,
  `date_creation` date NOT NULL,
  `id_user` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `offres`
--

INSERT INTO `offres` (`id_offre`, `url_photo`, `commentaire`, `date_creation`, `id_user`) VALUES
(1, 'toto', 'Je donne des fraises et des carottes', '2019-02-04', 1);

-- --------------------------------------------------------

--
-- Structure de la table `offres_categories`
--

CREATE TABLE `offres_categories` (
  `id_offre` int(11) NOT NULL,
  `id_categorie` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `offres_categories`
--

INSERT INTO `offres_categories` (`id_offre`, `id_categorie`) VALUES
(1, 1),
(1, 2);

-- --------------------------------------------------------

--
-- Structure de la table `users`
--

CREATE TABLE `users` (
  `id_user` int(11) NOT NULL,
  `nom` varchar(255) NOT NULL,
  `prenom` varchar(255) NOT NULL,
  `adresse` varchar(255) NOT NULL,
  `code_postal` smallint(6) NOT NULL,
  `commune` varchar(255) NOT NULL,
  `statut` varchar(255) DEFAULT NULL,
  `latitude` double NOT NULL,
  `longitude` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `users`
--

INSERT INTO `users` (`id_user`, `nom`, `prenom`, `adresse`, `code_postal`, `commune`, `statut`, `latitude`, `longitude`) VALUES
(1, 'ahadach', 'youness', '10 du Praley', 70, 'Haute-Saône', NULL, 47.611218, 6.170411),
(2, 'Thorez', 'Yohann', '5 rue du Praley', 70, 'H-S', NULL, 47.620706, 6.119174),
(3, 'Doe', 'John', '10 rue de Vesoul', 70, 'H-S', NULL, 47.583636, 6.040764),
(4, 'Dupont', 'Louis', '4 rue de Vesoul', 70, 'H-S', NULL, 47.600457, 6.318684),
(5, 'Dupont', 'Marie', '16 rue du Troc', 70, 'HS', NULL, 47.548343, 6.287785),
(6, 'Proviste', 'Alain', '20 rue du stade', 70, 'HS', NULL, 47.509862, 6.197491),
(7, 'Mathieu', 'Marie', '34 place du troc', 70, 'HS', NULL, 47.682113, 6.168652),
(8, 'Dupont', 'Isabelle', '45 rue de Vesoul', 70, 'HS', NULL, 47.708687, 6.078014),
(9, 'Dumont', 'Hervé', '12 faubourg Tarragnoz', 70, 'HS', NULL, 47.6526, 6.057243),
(10, 'Bouton', 'Adrien', '40 rue du troc', 70, 'HS', NULL, 47.542561, 6.034927),
(11, 'Michelle', 'Eva', '33 place du fruit', 70, 'HS', NULL, 47.457658, 6.139469),
(12, 'Dujardin', 'Alphonse', '3 rue du pré', 70, 'HS', NULL, 47.500585, 6.172771),
(13, 'Dupré', 'Louis', '45 rue du jardin', 70, 'HS', NULL, 47.530497, 6.273365),
(14, 'Lapelouse', 'Vincent', '34 place du troc', 70, 'HS', NULL, 47.592817, 6.190281),
(15, 'Dufour', 'Arthur', '76 place du troc', 70, 'hs', NULL, 47.680807, 6.263924),
(16, 'robin', 'Louise', '44 place du stade', 70, 'HS', NULL, 47.643267, 6.151142),
(17, 'Avan', 'Luc', '2 faubourg rivotte', 70, 'hs', NULL, 47.683962, 6.323147),
(18, 'Lavalle', 'Marc', '10 rue du Praley', 70, 'HS', NULL, 47.628461, 6.034756),
(19, 'Avant', 'Michael', '90 rue du Praley', 70, 'hs', NULL, 47.637021, 6.167965),
(20, 'Persil', 'Luc', '3 rue du troc', 70, 'hs', NULL, 47.543245, 6.250019),
(21, 'Pelouse', 'Arnaud', '49 place du jardin', 70, 'hs', NULL, 47.483882, 6.228046),
(22, 'Damien', 'Damien', '30 place du jardin', 70, 'HS', NULL, 47.646274, 6.155605),
(23, 'Anice', 'Christian', '3 faubourg rivotte', 70, 'HS', NULL, 47.620825, 6.195774),
(24, 'Michelin', 'Benoit', '9 place du jardin', 70, 'HS', NULL, 47.673791, 6.337223),
(25, 'Mouche', 'violette', '4 place du praley', 70, 'HS', NULL, 47.734094, 6.307697),
(26, 'Bolognaise', 'Adrien', '3 avenue du pré', 70, 'hs', NULL, 47.688585, 6.112347),
(27, 'Michele', 'Marise', '4 place du pré', 70, 'hs', NULL, 47.678877, 5.941715),
(28, 'Mie', 'Coralie', '4 rue de la chance', 70, 'hs', NULL, 47.645118, 5.935879),
(29, 'Martin', 'Martin', '98 avenue de la pelouse', 70, 'hs', NULL, 47.612725, 5.87923),
(30, 'Malou', 'Eddy', '7 avenue d\'europe', 70, 'hs', NULL, 47.633088, 5.968838),
(31, 'Tintin', 'Chloé', '44 rue du troc', 70, 'hs', NULL, 47.540464, 5.844898),
(32, 'Bond', 'James', '19 place du jardin', 70, 'hs', NULL, 47.584944, 5.974674),
(33, 'Bois', 'Lucas', '92 rue de paris', 70, 'HS', NULL, 47.56294, 6.028919),
(34, 'Amali', 'Martine', '45 rue de paris', 70, 'hs', NULL, 47.506151, 6.084881),
(35, 'Lebon', 'Christophe', '20 place de paris', 70, 'hs', NULL, 47.694131, 6.210537);

-- --------------------------------------------------------

--
-- Structure de la table `users_offres`
--

CREATE TABLE `users_offres` (
  `id_offre` int(11) NOT NULL,
  `id_user` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `users_offres`
--

INSERT INTO `users_offres` (`id_offre`, `id_user`) VALUES
(1, 1);

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id_categorie`);

--
-- Index pour la table `offres`
--
ALTER TABLE `offres`
  ADD PRIMARY KEY (`id_offre`),
  ADD UNIQUE KEY `offres_AK` (`id_user`);

--
-- Index pour la table `offres_categories`
--
ALTER TABLE `offres_categories`
  ADD PRIMARY KEY (`id_offre`,`id_categorie`),
  ADD KEY `offres_categories_categories0_FK` (`id_categorie`);

--
-- Index pour la table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id_user`);

--
-- Index pour la table `users_offres`
--
ALTER TABLE `users_offres`
  ADD PRIMARY KEY (`id_offre`,`id_user`),
  ADD KEY `users_offres_users0_FK` (`id_user`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `categories`
--
ALTER TABLE `categories`
  MODIFY `id_categorie` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT pour la table `offres`
--
ALTER TABLE `offres`
  MODIFY `id_offre` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT pour la table `users`
--
ALTER TABLE `users`
  MODIFY `id_user` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `offres_categories`
--
ALTER TABLE `offres_categories`
  ADD CONSTRAINT `offres_categories_categories0_FK` FOREIGN KEY (`id_categorie`) REFERENCES `categories` (`id_categorie`),
  ADD CONSTRAINT `offres_categories_offres_FK` FOREIGN KEY (`id_offre`) REFERENCES `offres` (`id_offre`);

--
-- Contraintes pour la table `users_offres`
--
ALTER TABLE `users_offres`
  ADD CONSTRAINT `users_offres_offres_FK` FOREIGN KEY (`id_offre`) REFERENCES `offres` (`id_offre`),
  ADD CONSTRAINT `users_offres_users0_FK` FOREIGN KEY (`id_user`) REFERENCES `users` (`id_user`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
